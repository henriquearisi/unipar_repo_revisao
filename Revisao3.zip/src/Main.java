import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Produto> produtos = new ArrayList<>();

        while (true) {
            System.out.println("Selecione uma opção:");
            System.out.println("1. Adicionar novo produto");
            System.out.println("2. Atualizar preço ou quantidade de um produto existente");
            System.out.println("3. Exibir detalhes de todos os produtos");
            System.out.println("4. Sair");

            int opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar o buffer do scanner

            switch (opcao) {
                case 1:
                    System.out.println("Digite o nome do produto:");
                    String nome = scanner.nextLine();
                    System.out.println("Digite o preço do produto:");
                    double preco = scanner.nextDouble();
                    System.out.println("Digite a quantidade em estoque do produto:");
                    int quantidadeEmEstoque = scanner.nextInt();
                    scanner.nextLine(); // Limpar o buffer do scanner
                    produtos.add(new Produto(nome, preco, quantidadeEmEstoque));
                    System.out.println("Produto adicionado com sucesso!");
                    break;
                case 2:
                    if (produtos.isEmpty()) {
                        System.out.println("Nenhum produto adicionado ainda.");
                    } else {
                        System.out.println("Selecione o produto pelo índice:");
                        for (int i = 0; i < produtos.size(); i++) {
                            System.out.println((i + 1) + ". " + produtos.get(i).getNome());
                        }
                        int indiceProduto = scanner.nextInt();
                        if (indiceProduto >= 1 && indiceProduto <= produtos.size()) {
                            Produto produto = produtos.get(indiceProduto - 1);
                            System.out.println("Digite o novo preço do produto:");
                            double novoPreco = scanner.nextDouble();
                            System.out.println("Digite a nova quantidade em estoque do produto:");
                            int novaQuantidade = scanner.nextInt();
                            scanner.nextLine(); // Limpar o buffer do scanner
                            produto.setPreco(novoPreco);
                            produto.setQuantidadeEmEstoque(novaQuantidade);
                            System.out.println("Produto atualizado com sucesso!");
                        } else {
                            System.out.println("Índice inválido.");
                        }
                    }
                    break;
                case 3:
                    if (produtos.isEmpty()) {
                        System.out.println("Nenhum produto cadastrado.");
                    } else {
                        System.out.println("Detalhes de todos os produtos:");
                        for (int i = 0; i < produtos.size(); i++) {
                            Produto produto = produtos.get(i);
                            System.out.println((i + 1) + ". " + produto.getNome());
                            System.out.println("   Preço: " + produto.getPreco());
                            System.out.println("   Quantidade em estoque: " + produto.getQuantidadeEmEstoque());
                        }
                    }
                    break;
                case 4:
                    System.out.println("Saindo...");
                    System.exit(0);
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
}

