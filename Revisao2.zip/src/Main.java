public class Main {
    public static void main(String[] args) {
        // Criando objetos da classe Produto e testando os métodos
        Produto produto1 = new Produto("Camiseta", 29.99, 50);
        Produto produto2 = new Produto("Calça Jeans", 79.90, 30);

        // Exibindo informações dos produtos
        System.out.println("Informações do Produto 1:");
        System.out.println("Nome: " + produto1.getNome());
        System.out.println("Preço: R$" + produto1.getPreco());
        System.out.println("Quantidade em Estoque: " + produto1.getQuantidadeEmEstoque());
        System.out.println();

        System.out.println("Informações do Produto 2:");
        System.out.println("Nome: " + produto2.getNome());
        System.out.println("Preço: R$" + produto2.getPreco());
        System.out.println("Quantidade em Estoque: " + produto2.getQuantidadeEmEstoque());
        System.out.println();

        // Modificando atributos do Produto 1
        produto1.setPreco(34.99);
        produto1.setQuantidadeEmEstoque(60);

        // Exibindo informações atualizadas do Produto 1
        System.out.println("Informações atualizadas do Produto 1:");
        System.out.println("Nome: " + produto1.getNome());
        System.out.println("Preço: R$" + produto1.getPreco());
        System.out.println("Quantidade em Estoque: " + produto1.getQuantidadeEmEstoque());
    }
}
