import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita ao usuário o raio e a cor do círculo
        System.out.print("Digite o raio do círculo: ");
        double raio = scanner.nextDouble();
        scanner.nextLine(); // Consumir a quebra de linha pendente
        System.out.print("Digite a cor do círculo: ");
        String cor = scanner.nextLine();

        // Cria um objeto Circulo com os valores fornecidos pelo usuário
        Circulo circulo = new Circulo(raio, cor);

        // Exibe as características do círculo
        System.out.println("\nCaracterísticas do Círculo:");
        System.out.println("Raio: " + circulo.getRaio());
        System.out.println("Cor: " + circulo.getCor());
        System.out.println("Área: " + circulo.calcularArea());
        System.out.println("Perímetro: " + circulo.calcularPerimetro());

        scanner.close();
    }
}
