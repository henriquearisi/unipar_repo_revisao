// Classe Circulo
class Circulo {
    private double raio;
    private String cor;

    // Método construtor
    public Circulo(double raio, String cor) {
        this.raio = raio;
        this.cor = cor;
    }

    // Métodos de acesso (getters)
    public double getRaio() {
        return raio;
    }

    public String getCor() {
        return cor;
    }

    // Método para calcular a área do círculo
    public double calcularArea() {
        return Math.PI * Math.pow(raio, 2);
    }

    // Método para calcular o perímetro do círculo
    public double calcularPerimetro() {
        return 2 * Math.PI * raio;
    }
}
