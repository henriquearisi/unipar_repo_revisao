import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Criação de objetos Produto utilizando os diferentes construtores
        Produto produto1 = new Produto("Camiseta");
        Produto produto2 = new Produto("Calça Jeans", 89.99);
        Produto produto3 = new Produto("Tênis Esportivo", 129.99, 20);

        // Exibição das características dos produtos criados
        System.out.println("Produto 1:");
        System.out.println("Nome: " + produto1.getNome());
        System.out.println("Preço: " + produto1.getPreco());
        System.out.println("Quantidade em Estoque: " + produto1.getQuantidadeEmEstoque());

        System.out.println("\nProduto 2:");
        System.out.println("Nome: " + produto2.getNome());
        System.out.println("Preço: " + produto2.getPreco());
        System.out.println("Quantidade em Estoque: " + produto2.getQuantidadeEmEstoque());

        System.out.println("\nProduto 3:");
        System.out.println("Nome: " + produto3.getNome());
        System.out.println("Preço: " + produto3.getPreco());
        System.out.println("Quantidade em Estoque: " + produto3.getQuantidadeEmEstoque());

        scanner.close();
    }
}
