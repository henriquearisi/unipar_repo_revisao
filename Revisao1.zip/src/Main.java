public class Main {
    public static void main(String[] args) {
        // Criando objetos da classe Carro e testando os métodos
        Carro carro1 = new Carro("Toyota", "Corolla", 2020, "Prata");
        Carro carro2 = new Carro("Honda", "Civic", 2019, "Preto");

        // Exibindo informações dos carros
        System.out.println("Informações do Carro 1:");
        carro1.exibirInformacoes();
        System.out.println();

        System.out.println("Informações do Carro 2:");
        carro2.exibirInformacoes();
        System.out.println();

        // Modificando atributos do Carro 1
        carro1.setAno(2021);
        carro1.setCor("Branco");

        // Exibindo informações atualizadas do Carro 1
        System.out.println("Informações atualizadas do Carro 1:");
        carro1.exibirInformacoes();
    }
}
